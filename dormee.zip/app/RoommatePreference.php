<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoommatePreference extends Model
{
    //
}
