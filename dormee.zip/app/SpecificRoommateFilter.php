<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SpecificRoommateFilter extends Model
{
    //
}
