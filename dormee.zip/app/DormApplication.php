<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DormApplication extends Model
{
    //
}
