<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DormAttribute extends Model
{
    //
}
