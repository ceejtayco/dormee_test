<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DormPhoto extends Model
{
    //
}
