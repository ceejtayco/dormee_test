
<!-- Meta Tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="LERAMIZ Landing Page Template">
<meta name="keywords" content="LERAMIZ, unica, creative, html">
<meta name="viewport" content="width=device-width, initial-scale=1.0">	
<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title>
	<?php echo e(config('app.name') 
		+ " " 
		+ basename($_SERVER['PHP_SELF'], '.php')); ?>

</title>


<!-- Fonts -->
<link rel="dns-prefetch" href="//fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">


<!-- Favicon -->
<link href="img/favicon.ico" rel="shortcut icon"/>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">

<!-- Stylesheets -->
<link href="<?php echo e(URL::asset('public/css/app.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/bootstrap.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/font-awesome.min.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/animate.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/owl.carousel.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(URL::asset('public/css/style.css')); ?>"/>

