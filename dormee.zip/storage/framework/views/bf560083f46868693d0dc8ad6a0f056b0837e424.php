<div style="background-image: url('<?php echo e(URL::asset('public/img/bg/sunset_bldg.jpg')); ?>'); background-repeat: no-repeat; background-size: 100%; background-attachment: fixed; background-position: bottom;">



<?php $__env->startSection('content'); ?>

<div class="row justify-content-center" >
  <div class="col-md-6">
    <div class="card mx-4">
      <div class="card-body p-4 text-center">
      <?php if(auth()->guard()->guest()): ?> 
        <h1>Registration</h1>
        <p class="text-muted">Create your free account</p>
        <?php echo $__env->make('forms.register', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php else: ?>
      <div class="btn-warning">You're already logged in.</div>
      <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>