<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php echo $__env->make('static.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
    <?php echo $__env->make('static.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('header'); ?>
    <div id="app">
        <main class="pt-4 main-content">
        	<?php if((basename($_SERVER['REQUEST_URI']) !== 'dormee')): ?>
        	<div class="container-fluid">
        	<?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        	<?php if(basename($_SERVER['REQUEST_URI']) !== 'dormee'): ?>
        	</div>
        	<?php endif; ?>
        </main>
    </div>
    <?php echo $__env->make('static.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('static.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
