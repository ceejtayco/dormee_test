<nav class="navbar navbar-expand-md navbar-inverse set-top shadowed text-white">
    <a class="navbar-brand pb-2" href="<?php echo e(URL::to('index')); ?>">
    <img class="mb-5 pb-5 img-hover" src="<?php echo e(asset('public/img/logo.png')); ?>" alt="<?php echo e(config('app.name')); ?>" style="margin-top: -9px;">
    </a>
    <button type="button" class="navbar-toggle mb-3" data-toggle="collapse" data-target="#navbarSupportedContent">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto p-2 navbar-inverse">
             <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item py-2">
                    <a class="nav-link" href="login"><?php echo e(('Login')); ?></a>
                </li>
                <?php if(Route::has('register')): ?>
                <li class="nav-item py-2">
                    <a class="nav-link" href="register"><?php echo e(('Register')); ?></a>
                </li>
                <?php endif; ?>
                <?php else: ?>
                <li class="nav-item py-2">
                    Howdy, 
                    <a href="<?php echo e(URL::to('dashboard')); ?>" class="mx-2 mr-5">
                        <?php echo e(Auth::user()->username); ?> 
                    </a>
                    <a href="<?php echo e(URL::to('logout')); ?>">
                        <?php echo e(('Logout')); ?>

                    </a>
                </li>
                <li class="nav-item pl-5 py-2">
                    
                    <a href="<?php echo e(URL::to('dorms')); ?>" class="mx-2 mr-5">
                        Dorms
                    </a>
                    <a href="<?php echo e(URL::to('roommates')); ?>">
                        <?php echo e(('Roommates')); ?>

                    </a>
                </li>
                <?php endif; ?>
        </ul>
      
    </div>
</nav>

