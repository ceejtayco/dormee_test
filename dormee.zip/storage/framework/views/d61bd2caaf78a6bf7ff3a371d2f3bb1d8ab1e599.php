<?php $__env->startSection('content'); ?>
<div class="pt-5 text-white bg-primary">
    <div class="container">
      <div class="row">
        <div class="col-md-6 text-md-left text-center align-self-center my-5">
          <h1 class="display-1">Dorms</h1>
          <p class="lead">Search for the right one.&nbsp;</p>
          <div class="row mt-5">
            <div class="col-md-5 col-6">
              <a href="#">
         
            </div>
            <div class="col-md-5 col-6">
              <a href="#">
                
            </div>
          </div>
        </div>
        <div class="col-md-6 bg-light">
         </div>
      </div>
    </div>
</div>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <form id="dormSearch" class="form-inline" method="POST">
            <div class="input-group">
              <input type="text" class="form-control" placeholder="" name="query">
              <div class="input-group-append">
                <button class="btn btn-primary" type="button">Search</button>
              </div>

            </div>

        <label class="checkbox-inline" for="filters-0">
          <input type="checkbox" name="filters[]" id="filters-0" value="1">
          Roommates
        </label>
        <label class="checkbox-inline" for="filters-1">
          <input type="checkbox" name="filters[]" id="filters-1" value="2">
          Guests Allowed
        </label>
        <label class="checkbox-inline" for="filters-2">
          <input type="checkbox" name="filters[]" id="filters-2" value="3">
          Pets
        </label>
        <label class="checkbox-inline" for="filters-3">
          <input type="checkbox" name="filters[]" id="filters-3" value="4">
          Kitchen
        </label>
        <label class="checkbox-inline" for="filters-4">
          <input type="checkbox" name="filters[]" id="filters-4" value="5">
          Electric Fan
        </label>
        <label class="checkbox-inline" for="filters-5">
          <input type="checkbox" name="filters[]" id="filters-5" value="6">
          Air-con
        </label>
        <label class="checkbox-inline" for="filters-6">
          <input type="checkbox" name="filters[]" id="filters-6" value="7">
          Laundromat
        </label>
        <label class="checkbox-inline" for="filters-7">
          <input type="checkbox" name="filters[]" id="filters-7" value="8">
          Internet
        </label>
        <label class="checkbox-inline" for="filters-8">
          <input type="checkbox" name="filters[]" id="filters-8" value="9">
          TV
        </label>
        <label class="checkbox-inline" for="filters-9">
          <input type="checkbox" name="filters[]" id="filters-9" value="10">
          Closet
        </label>
        <label class="checkbox-inline" for="filters-10">
          <input type="checkbox" name="filters[]" id="filters-10" value="11">
          Parking
        </label>
        <label class="checkbox-inline" for="filters-11">
          <input type="checkbox" name="filters[]" id="filters-11" value="12">
          Elevator
        </label>
        <label class="checkbox-inline" for="filters-12">
          <input type="checkbox" name="filters[]" id="filters-12" value="bathtub">
          Wi-Fi
        </label>
        <label class="checkbox-inline" for="filters-13">
          <input type="checkbox" name="filters[]" id="filters-13" value="14">
          Bathroom
    </div>

          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">

    <?php 
      $dorms = \App\Dorm::all()->where('status', 1);
    $i = 0;
    foreach($dorms as $dorm) {
      if ($i + 1 % 3 == 0) {
      
        echo "<div class='row'>";
      }

      echo "<div class='col-md-4'>
          <div class='card'>
            <img class='card-img-top' src='https://pingendo.com/assets/photos/wireframe/photo-1.jpg'>
            <div class='card-body'>
              <h5 class='card-title'>$dorm->name</h5>
              <p class='card-text'>$dorm->address</p>
              <p class='card-text'>$dorm->description</p>
              <a href='dorms/'" . $dorm->id . " class='btn btn-primary'>View Dorm</a>
            </div>
          </div>
        </div>";
    }



     ?>
  
     
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>