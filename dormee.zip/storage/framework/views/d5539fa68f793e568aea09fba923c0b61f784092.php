<?php $__env->startSection('content'); ?>
<div class="card mx-4 my-5 p-5">
<?php if(isset($dorm)): ?>
<?php echo $__env->make('sections.view_dorm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
<h2 style="text-align:center;" class="py-4 my-4">
	My Dorms
	<hr>
</h2>
<?php echo $__env->make('sections.dorms', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>