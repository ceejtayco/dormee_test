<?php $__env->startSection('content'); ?>

<div class="pt-5 text-white bg-primary " style="background-image:url('<?php echo e(asset('public/img/bg/bed_plant.jpg')); ?>'); background-size: 100%; background-position: bottom center; min-height: 500px; height: 500px; background-size: cover; padding: 0;">
  <div class="container" style="background-color: rgba(0, 0,0,0.6); height: 200px;">
      <div class="row">
        <div class="col-md-6 text-md-left text-center my-5">
          <h1 class="display-1">Dorms</h1>
          <p class="lead">Search for the right one.&nbsp;</p>
        </div>
        <div class="col-md-6 bg-light text-dark py-5 shadowed">
          <div class="row">
            <div class="col-md-4 text-dark">
                <form id="dormSearch" class="form-inline" method="POST">
                <div class="input-group">
                  Name
                  <input type="text" class="form-control" placeholder="" name="query">
                </div>
                <div class="py-4">
                  <div class="pb-4">
                     Attributes
                  </div>
                 
                   <?php echo $__env->make('forms.attributes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
               
              
            </div>

              <div class="col-md-4">
                <div class="input-group">
                Budget <input type="number" class="form-control"placeholder="" name="budget" min="0">
                </div>
                 <div class="input-group mt-4">
                Location <input type="number" class="form-control"placeholder="" name="budget">
                <iframe src="https://www.google.com/maps/d/embed?mid=13nGZrOR_TMPasVSkFcG1b0UwYcaxsjbw&hl=en" width="160" height="180"></iframe>
                </div>

              </div>

              <div class="col-md-4 hidden-box">
                <button id="btnShowFilters" class="btn btn-primary mt-4">Filters</button>
                <div id="filtersBox" class="hidden-box" style="display: none;">
                  <label class="checkbox" for="filters-0">
                    <input type="checkbox" name="filters[]" id="filters-0" value="1">
                    Roommates
                  </label>
                  <label class="checkbox" for="filters-1">
                    <input type="checkbox" name="filters[]" id="filters-1" value="2">
                    Guests Allowed
                  </label>
                  <label class="checkbox" for="filters-2">
                    <input type="checkbox" name="filters[]" id="filters-2" value="3">
                    Pets
                  </label>
                  <label class="checkbox" for="filters-3">
                    <input type="checkbox" name="filters[]" id="filters-3" value="4">
                    Kitchen
                  </label>
                  <label class="checkbox" for="filters-4">
                    <input type="checkbox" name="filters[]" id="filters-4" value="5">
                    Electric Fan
                  </label>
                  <label class="checkbox" for="filters-5">
                    <input type="checkbox" name="filters[]" id="filters-5" value="6">
                    Air-con
                  </label>
                  <label class="checkbox" for="filters-6">
                    <input type="checkbox" name="filters[]" id="filters-6" value="7">
                    Laundromat
                  </label>
                  <label class="checkbox" for="filters-7">
                    <input type="checkbox" name="filters[]" id="filters-7" value="8">
                    Internet
                  </label>
                  <label class="checkbox" for="filters-8">
                    <input type="checkbox" name="filters[]" id="filters-8" value="9">
                    TV
                  </label>
                  <label class="checkbox" for="filters-9">
                    <input type="checkbox" name="filters[]" id="filters-9" value="10">
                    Closet
                  </label>
                  <label class="checkbox" for="filters-10">
                    <input type="checkbox" name="filters[]" id="filters-10" value="11">
                    Parking
                  </label>
                  <label class="checkbox" for="filters-11">
                    <input type="checkbox" name="filters[]" id="filters-11" value="12">
                    Elevator
                  </label>
                  <label class="checkbox" for="filters-12">
                    <input type="checkbox" name="filters[]" id="filters-12" value="bathtub">
                    Wi-Fi
                  </label>
                  <label class="checkbox" for="filters-13">
                    <input type="checkbox" name="filters[]" id="filters-13" value="14">
                    Bathroom
                  </label>
                </div>
              </div>
               
                <div class="col-md-12 text-center m-auto">
                  
            <button class="btn btn-primary">Search Dorms</button>
                </div>
          </form>

          </div> <!-- row -->
          
        </div>   <!--col-md-6 -->
       
      </div>  <!-- row -->
    </div> <!-- container -->
  </div> <!-- container -->

<div class="container py-5">

  <?php 
  $dorms = \App\Dorm::all()->where('status', 1);
  $i = 0;
  foreach($dorms as $dorm) {
  if ($i + 1 % 3 == 0) {

  echo "<div class='row'>";
  }

  echo "<div class='col-md-4'>
    <div class='card'>
      <img class='card-img-top' src='https://pingendo.com/assets/photos/wireframe/photo-1.jpg'>
      <div class='card-body'>
        <h5 class='card-title'>$dorm->name</h5>
        <p class='card-text'>$dorm->address</p>
        <p class='card-text'>$dorm->description</p>
        <a href='dorms/'" . $dorm->id . " class='btn btn-primary'>View Dorm</a>
      </div>
    </div>
  </div>";

  if ($i + 1 % 3 == 0) {

echo "</div>";
}
}



 ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>