<h2>Sign up</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
<button class="btn btn-primary active mt-3" type="button" onclick="window.location.href='register'">
  Register Now
</button> 