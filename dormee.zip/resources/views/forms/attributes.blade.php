<div class="slidecontainer">
  Cleanliness <input type="range" min="1" max="5" name="slider1" value="1" class="slider" id="slider1">
  <p class="text-dark">Value: <span id="value1" class="text-dark"></span></p>
</div>
<div class="slidecontainer">
  Safety <input type="range" min="1" max="5" name="slider2" value="1" class="slider " id="slider2">
  <p class="text-dark">Value: <span id="value2" class="text-dark"></span></p>
</div>
<div class="slidecontainer">
  Ambiance <input type="range" min="1" max="5" name="slider3" value="1" class="slider" id="slider3">
  <p class="text-dark">Value: <span id="value3" class="text-dark"></span></p>
</div>
<div class="slidecontainer">
  Facilities <input type="range" min="1" max="5" name="slider4" value="1" class="slider" id="slider4">
  <p class="text-dark">Value: <span id="value4" class="text-dark"></span></p>
</div>
<div class="slidecontainer">
  Access to Transport <input type="range" min="1" max="5" name="slider5" value="1" class="slider" id="slider5">
  <p class="text-dark">Value: <span id="value5" class="text-dark"></span></p>
</div>
