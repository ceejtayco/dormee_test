@extends('layouts.app')

@section('content')

<div class="my-5 mx-5 card p-5">


@include('forms.dorm')


</div>

@endsection 