@extends('layouts.app')
@section('content')
	<div class="row jumbotron-grey">
		Error
	</div>

	<p>
		This page is off limits!
	</p>
@stop